package lildwagz.com.numbproject.auth;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.Random;

import lildwagz.com.numbproject.Model.ResponseRegister;
import lildwagz.com.numbproject.Network.ApiServices;
import lildwagz.com.numbproject.Network.RetrofitClient;
import lildwagz.com.numbproject.R;
import lildwagz.com.numbproject.func.Preferences;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class registrasi extends AppCompatActivity {

    EditText edt_signup_username,edt_signup_email, edt_signup_password, edt_signin;
    Button button_signup;
    AlertDialog.Builder alert;
    int randomCode = 0;
    Bundle Bundle;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registrasi);

        int m = (int) Math.pow(10, 5 - 1);
        randomCode = m + new Random().nextInt(9 * m);

        Log.d("LOG", "RANDOM : " + randomCode);
        edt_signup_username = (EditText)findViewById(R.id.edt_username_signup);
        edt_signup_password = (EditText)findViewById(R.id.edt_password_signup);
        edt_signup_email = (EditText)findViewById(R.id.edt_email_signup);
        button_signup =(Button)findViewById(R.id.btn_button_signup);
        edt_signin = (EditText)findViewById(R.id.edt_signin);

        edt_signin.setClickable(true);
        edt_signin.setFocusable(false);
        edt_signin.setInputType(InputType.TYPE_NULL);

        edt_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(registrasi.this, login.class));
                finish();
            }
        });

        button_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                moduleConfirmPut();

            }
        });

    }

    public void moduleConfirmPut() {
        String  getUsername, getPassword, getEmail;
        boolean cancel = false;

        getUsername = edt_signup_username.getText().toString();
        getPassword = edt_signup_password.getText().toString();
        getEmail = edt_signup_email.getText().toString();


        if (TextUtils.isEmpty(getUsername)) {
            edt_signup_username.setError("Isi Username Anda!");
            edt_signup_username.requestFocus();
            cancel = true;
        } else if (cekUser(getUsername)) {
            edt_signup_password.setError("Isi Password Anda!");
            edt_signup_password.requestFocus();
            cancel = true;
        } else if (TextUtils.isEmpty(getPassword)) {
            edt_signup_password.setError("Isi Password Anda!");
            edt_signup_email.requestFocus();
            cancel = true;

        } else if (TextUtils.isEmpty(getEmail)) {
            edt_signup_email.setError("Isi Email Anda!");
            edt_signup_email.requestFocus();
        } else {
            Preferences.setRegisteredUser(getBaseContext(), getUsername);
            Preferences.setRegisteredPass(getBaseContext(), getPassword);
            moduleRegisterUser(randomCode, getUsername, getPassword, getEmail);
        }
    }
    public void moduleRegisterUser(int kd_user, String usr_user, String pwd_user, String eml_user) {

        final ProgressDialog dialog = ProgressDialog.show(registrasi.this, "Progress register ongoing", "Please wait....");

        ApiServices apiServices = RetrofitClient.getInstaceRetrofit();
        Call<ResponseRegister> userRegister = apiServices.registerUser(kd_user, usr_user, pwd_user, eml_user);

        userRegister.enqueue(new Callback<ResponseRegister>() {
            @Override
            public void onResponse(Call<ResponseRegister> call, Response<ResponseRegister> response) {
                if (response.isSuccessful()) {
                    dialog.dismiss();

                    String pesan = response.body().getMessage();
                    Boolean status = response.body().isStatus();

                    if (status.equals(true)) {
                        Toast.makeText(registrasi.this, "yuhuu! " + pesan, Toast.LENGTH_SHORT).show();
                        String body = String.valueOf(response.body().getDataUser());

                        Bundle = new Bundle();
                        Log.d("LOG", "DATA : " + body);

                        Bundle.putString("SENT_USERNAME", usr_user);
                        Bundle.putString("SENT_PASSWORD", pwd_user);
                        Intent adpIntent = new Intent(registrasi.this, login.class);
                        adpIntent.putExtras(Bundle);
                        startActivity(adpIntent);

                        finish();
                    } else {
                        Toast.makeText(registrasi.this, "Oopss! " + pesan, Toast.LENGTH_SHORT).show();
                        dialog.dismiss();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseRegister> call, Throwable t) {
                Toast.makeText(registrasi.this, "Check your connection now!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private boolean cekPassword(String passkey, String repasskey) {
        return passkey.equals(repasskey);
    }

    private boolean cekUser(String user) {
        return user.equals(Preferences.getRegisteredUser(getBaseContext()));
    }

}
