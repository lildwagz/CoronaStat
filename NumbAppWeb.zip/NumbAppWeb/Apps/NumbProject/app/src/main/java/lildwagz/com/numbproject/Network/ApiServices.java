package lildwagz.com.numbproject.Network;

import lildwagz.com.numbproject.Model.ResponseLogin;
import lildwagz.com.numbproject.Model.ResponseRegister;
import retrofit2.Call;
import retrofit2.http.Field;
import retrofit2.http.FormUrlEncoded;
import retrofit2.http.POST;

public interface ApiServices {

    @FormUrlEncoded
    @POST("signup.php")
    Call<ResponseRegister> registerUser (
            @Field("user_kode") int str_kodeuser,
            @Field("user_username") String str_username,
            @Field("user_password") String str_password,
            @Field("user_email") String str_email
    );
    @FormUrlEncoded
    @POST("signin.php")
    Call<ResponseLogin> loginUser (
            @Field("username") String log_username,
            @Field("password") String log_password
    );

}
