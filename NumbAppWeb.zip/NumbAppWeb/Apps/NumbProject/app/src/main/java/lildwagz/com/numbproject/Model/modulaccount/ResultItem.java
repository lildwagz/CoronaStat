package lildwagz.com.numbproject.Model.modulaccount;


import com.google.gson.annotations.SerializedName;

public class ResultItem{

    @SerializedName("kode_user")
    private String kodeUser;

    @SerializedName("email_user")
    private String emailUser;

    @SerializedName("username_user")
    private String usernameUser;

    public void setKodeUser(String kodeUser){
        this.kodeUser = kodeUser;
    }

    public String getKodeUser(){
        return kodeUser;
    }

    public void setEmailUser(String emailUser){
        this.emailUser = emailUser;
    }

    public String getEmailUser(){
        return emailUser;
    }


    public void setUsernameUser(String usernameUser){
        this.usernameUser = usernameUser;
    }

    public String getUsernameUser(){
        return usernameUser;
    }


    @Override
    public String toString(){
        return
                "ResultItem{" +
                        "kode_user = '" + kodeUser + '\'' +
                        ",email_user = '" + emailUser + '\'' +
                        ",username_user = '" + usernameUser + '\'' +
                        "}";
    }
}