package lildwagz.com.numbproject.Model;

import com.google.gson.annotations.SerializedName;

public class DataUserItem {
    @SerializedName("kode_user")
    private String kodeUser;

    @SerializedName("password_user")
    private String passwordUser;

    @SerializedName("email_user")
    private String emailUser;

    @SerializedName("user_created")
    private String userCreated;

    @SerializedName("username_user")
    private String usernameUser;

    public void setKodeUser(String kodeUser){
        this.kodeUser = kodeUser;
    }

    public String getKodeUser(){
        return kodeUser;
    }


    public void setPasswordUser(String passwordUser){
        this.passwordUser = passwordUser;
    }

    public String getPasswordUser(){
        return passwordUser;
    }

    public void setEmailUser(String emailUser){
        this.emailUser = emailUser;
    }

    public String getEmailUser(){
        return emailUser;
    }


    public void setUserCreated(String userCraeted){
        this.userCreated = userCraeted;
    }

    public String getUserCreated(){
        return userCreated;
    }

    public void setUsernameUser(String usernameUser){
        this.usernameUser = usernameUser;
    }

    public String getUsernameUser(){
        return usernameUser;
    }

    @Override
    public String toString(){
        return
                "DataUserItem{" +
                        "kode_user = '" + kodeUser + '\'' +
                        ",password_user = '" + passwordUser + '\'' +
                        ",email_user = '" + emailUser + '\'' +
                        ",user_created = '" + userCreated + '\'' +
                        ",username_user = '" + usernameUser + '\'' +
                        "}";
    }
}
