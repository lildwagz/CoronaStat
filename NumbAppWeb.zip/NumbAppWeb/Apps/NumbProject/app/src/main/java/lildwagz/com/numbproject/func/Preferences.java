package lildwagz.com.numbproject.func;

import android.content.Context;
import android.content.SharedPreferences;
import android.preference.PreferenceManager;

public class Preferences {
    static final String KEY_USER_TERREGISTER = "username_ref";
    static final String KEY_PASS_TERREGISTER = "password_ref";

    static final String KEY_USERNAME_IS_LOGIN = "username_loggedin";
    static final String KEY_STATUS_IS_LOGIN = "status_username_loggedin";

    private static SharedPreferences getSharedPreferences(Context context) {
        return PreferenceManager.getDefaultSharedPreferences(context);
    }

    public static void setRegisteredUser(Context context, String username) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(KEY_USER_TERREGISTER, username);
        editor.apply();
    }

    public static String getRegisteredUser(Context context) {
        return getSharedPreferences(context).getString(KEY_USER_TERREGISTER,"");
    }

    public static void setRegisteredPass(Context context, String password) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(KEY_PASS_TERREGISTER, password);
        editor.apply();
    }

    public static String getRegisteredPass(Context context) {
        return getSharedPreferences(context).getString(KEY_PASS_TERREGISTER,"");
    }

    public static void setLoggedInUser(Context context, String username) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putString(KEY_USERNAME_IS_LOGIN, username);
        editor.apply();
    }

    public static String getLoggedInUser(Context context) {
        return getSharedPreferences(context).getString(KEY_USERNAME_IS_LOGIN,"");
    }

    // TODO 4: Preferensi untuk Status User yang sedang Login
    public static void setLoggedInStatus(Context context, Boolean status) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.putBoolean(KEY_STATUS_IS_LOGIN, status);
        editor.apply();
    }

    public static boolean getLoggedInStatus(Context context) {
        return getSharedPreferences(context).getBoolean(KEY_STATUS_IS_LOGIN,false);
    }

    // TODO 5: Clear Preferensi Login
    public static void clearLoggedInUser(Context context) {
        SharedPreferences.Editor editor = getSharedPreferences(context).edit();
        editor.remove(KEY_USERNAME_IS_LOGIN);
        editor.remove(KEY_STATUS_IS_LOGIN);
        editor.apply();
    }
}
