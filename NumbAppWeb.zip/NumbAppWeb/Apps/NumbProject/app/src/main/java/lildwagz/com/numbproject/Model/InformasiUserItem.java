package lildwagz.com.numbproject.Model;

import com.google.gson.annotations.SerializedName;

public class InformasiUserItem {
    @SerializedName("user_kode")
    private String kodeUser;

    @SerializedName("user_password")
    private String passwordUser;

    @SerializedName("user_email")
    private String emailUser;


    @SerializedName("user_created")
    private String userCreated;

    @SerializedName("user_username")
    private String usernameUser;


    public void setKodeUser(String kodeUser){
        this.kodeUser = kodeUser;
    }

    public String getKodeUser(){
        return kodeUser;
    }





    public void setPasswordUser(String passwordUser){
        this.passwordUser = passwordUser;
    }

    public String getPasswordUser(){
        return passwordUser;
    }

    public void setEmailUser(String emailUser){
        this.emailUser = emailUser;
    }

    public String getEmailUser(){
        return emailUser;
    }


    public void setUserCraeted(String userCraeted){
        this.userCreated = userCraeted;
    }

    public String getUserCraeted(){
        return userCreated;
    }

    public void setUsernameUser(String usernameUser){
        this.usernameUser = usernameUser;
    }

    public String getUsernameUser(){
        return usernameUser;
    }


    @Override
    public String toString(){
        return
                "InformasiUserItem{" +
                        "user_kode = '" + kodeUser + '\'' +
                        ",user_password = '" + passwordUser + '\'' +
                        ",user_email = '" + emailUser + '\'' +
                        ",user_craeted = '" + userCreated + '\'' +
                        ",user_username = '" + usernameUser + '\'' +
                        "}";
    }
}
