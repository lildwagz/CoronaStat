package lildwagz.com.numbproject.auth;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.ProgressDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputType;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import lildwagz.com.numbproject.Dashboard.DashboardActivity;
import lildwagz.com.numbproject.Model.ResponseLogin;
import lildwagz.com.numbproject.Network.ApiServices;
import lildwagz.com.numbproject.Network.RetrofitClient;
import lildwagz.com.numbproject.R;
import lildwagz.com.numbproject.func.Preferences;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class login extends AppCompatActivity {
    EditText username,password,edt_signup;
    Button button_signin;
    AlertDialog.Builder alert;
    boolean cancel;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        username = (EditText)findViewById(R.id.edt_username_signin);
        password = (EditText)findViewById(R.id.edt_password_signin);
        button_signin =(Button)findViewById(R.id.btn_button_signin);
        edt_signup = (EditText)findViewById(R.id.edt_signup);

        edt_signup.setClickable(true);
        edt_signup.setFocusable(false);
        edt_signup.setInputType(InputType.TYPE_NULL);

        edt_signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(login.this, registrasi.class));
                finish();
            }
        });
        if(getIntent().getExtras() != null){
            Bundle tampungBundle = getIntent().getExtras();
            username.setText(tampungBundle.getString("SENT_USERNAME"));
            password.setText(tampungBundle.getString("SENT_PASSWORD"));

        }else{
            //Toast.makeText(this, "Data gagal parsing. Try again!.", Toast.LENGTH_SHORT).show();
        }

        button_signin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                cancel = false;
                String upsetUsername = username.getText().toString();
                String upsetPassword = password.getText().toString();

                moduleConfirmPut(upsetUsername, upsetPassword);

            }
        });



    }


    @Override
    protected void onStart() {
        super.onStart();
        if (Preferences.getLoggedInStatus(getBaseContext())) {
            startActivity(new Intent(getBaseContext(), DashboardActivity.class));
            finish();
        }
    }

    public void clearPutSign() {
        username.setText("");
        password.setText("");
    }

    public void moduleConfirmPut(String confUsername, String confPassword) {

        if (TextUtils.isEmpty(confUsername)) {
            username.setError("This field username is required!");
            username.requestFocus();
            cancel = true;
        } else if (TextUtils.isEmpty(confPassword)) {
            password.setError("This field password id required!");
            password.requestFocus();
            cancel = true;
        } else {
            Preferences.setRegisteredUser(getBaseContext(), confUsername);
            Preferences.setRegisteredPass(getBaseContext(), confPassword);
            moduleLogin(confUsername, confPassword);
        }
    }

    private void moduleLogin(String susername, String spassword) {

        final ProgressDialog dialog = ProgressDialog.show(login.this, "Progress login ongoing.", "Please wait....");

        ApiServices apiServices = RetrofitClient.getInstaceRetrofit();

        Call<ResponseLogin> responseLoginCall = apiServices.loginUser(susername, spassword);
        responseLoginCall.enqueue(new Callback<ResponseLogin>() {
            @Override
            public void onResponse(Call<ResponseLogin> call, Response<ResponseLogin> response) {
                if (response.isSuccessful()) {
                    dialog.dismiss();
                    Log.d("LOG","LOGIN " + response.body().getInformasiUser());
                    String messageLogin = response.body().getMessage();
                    int messageCode = response.body().getCode();

                    if (messageCode == 200) {
                        Toast.makeText(login.this, messageLogin, Toast.LENGTH_SHORT).show();

                        String message = "Login successfully..";
                        if (messageLogin.equals(message)) {
                            moduleSignin();
                        }
                    } else {
                        Toast.makeText(login.this, messageLogin, Toast.LENGTH_SHORT).show();
                    }
                }
            }

            @Override
            public void onFailure(Call<ResponseLogin> call, Throwable t) {
                Toast.makeText(login.this, t.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });


    }

    public void moduleSignin() {
        Preferences.setLoggedInUser(getBaseContext(), Preferences.getRegisteredUser(getBaseContext()));
        Preferences.setLoggedInStatus(getBaseContext(), true);
        startActivity(new Intent(getBaseContext(), DashboardActivity.class));
        finish();
    }



}
