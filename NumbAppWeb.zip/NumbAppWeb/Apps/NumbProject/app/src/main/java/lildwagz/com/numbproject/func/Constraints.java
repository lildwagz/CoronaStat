package lildwagz.com.numbproject.func;

public class Constraints {
    public static final String BASE_URL = "https://lidwagz.000webhostapp.com/NumbAppWeb/auth/";
}
